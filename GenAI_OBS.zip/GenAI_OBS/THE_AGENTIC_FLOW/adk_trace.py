# adk_trace.py
import time
import json
from datetime import datetime

def _ts():
    return datetime.utcnow().isoformat()

# ------------------------------------------------------
# Basic Logging Helper
# ------------------------------------------------------
def log(msg, data=None):
    print(f"[OBS][{_ts()}] {msg}")
    if data:
        pretty = json.dumps(data, indent=2, ensure_ascii=False)
        print(pretty)

# ------------------------------------------------------
# Session Observability
# ------------------------------------------------------
def trace_session_created(user_id, session_id):
    log("SESSION CREATED", {"user_id": user_id, "session_id": session_id})

def trace_session_loaded(user_id, session_id):
    log("SESSION LOADED", {"user_id": user_id, "session_id": session_id})

def trace_session_deleted(user_id, session_id):
    log("SESSION DELETED", {"user_id": user_id, "session_id": session_id})

def trace_session_state_delta(session_id, delta):
    log("SESSION STATE UPDATED", {"session_id": session_id, "delta": delta})

# ------------------------------------------------------
# Event Observability
# ------------------------------------------------------
def trace_event(event):
    data = {
        "id": event.id,
        "author": event.author,
        "timestamp": event.timestamp,
        "actions": str(event.actions),
        "content": [],
    }

    if event.content and hasattr(event.content, "parts"):
        data["content"] = [p.text for p in event.content.parts if p.text]

    log("EVENT RECEIVED", data)

def trace_event_error(event):
    log("EVENT ERROR DETECTED", {"event_id": event.id})

def trace_event_final_response(text):
    log("FINAL RESPONSE PRODUCED", {"response": text})

# ------------------------------------------------------
# Routing Observability
# ------------------------------------------------------
def trace_agent_routing(selected_agent):
    log("ROUTING DECISION", {"selected_agent": selected_agent})

# ------------------------------------------------------
# Model Observability
# ------------------------------------------------------
def trace_model_call(model_name, prompt):
    log("MODEL INVOCATION", {"model": model_name, "prompt_excerpt": prompt[:200]})

def trace_model_output(output):
    log("MODEL OUTPUT", {"output_excerpt": output[:200]})

def trace_model_latency(latency):
    log("MODEL LATENCY (ms)", {"latency": latency})

# ------------------------------------------------------
# Artifact Observability
# ------------------------------------------------------
def trace_artifact_created(artifact_id, metadata=None):
    log("ARTIFACT CREATED", {"artifact_id": artifact_id, "metadata": metadata or {}})

# ------------------------------------------------------
# System Observability
# ------------------------------------------------------
def trace_runtime_reset(old_session, new_session):
    log("RUNTIME RESET", {"old_session": old_session, "new_session": new_session})
