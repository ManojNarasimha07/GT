from google.adk.models.lite_llm import LiteLlm
import litellm

class LiteLlmWithUsage(LiteLlm):
    async def run_llm(self, *args, **kwargs):
        """
        Override LiteLlm.run_llm so we can extract token usage
        and inject it into ADK agent_state.
        """
        response = await litellm.acompletion(
            model=self.model,
            api_key=self.api_key,
            messages=kwargs.get("messages"),
        )

        usage = response.get("usage", {})

        # Inject usage into ADK agent_state so Runner.forward_event() sees it  
        kwargs["agent_state"] = {
            "llm_input_tokens": usage.get("prompt_tokens"),
            "llm_output_tokens": usage.get("completion_tokens"),
            "llm_total_tokens": usage.get("total_tokens"),
        }

        # Wrap the response the way LiteLlm expects
        # (this preserves your ADK flow completely)
        text = response["choices"][0]["message"]["content"]
        return text, kwargs["agent_state"]
