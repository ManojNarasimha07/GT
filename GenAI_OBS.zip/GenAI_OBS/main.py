import asyncio
import time
from uuid import uuid4

import litellm
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.artifacts import InMemoryArtifactService
from google.adk.events import Event, EventActions

from THE_AGENTIC_FLOW.agent import root_agent


# ============================================================
# LITELLM TOKEN CAPTURE HOOK (FIXED)
# ============================================================

GLOBAL_LLM_TOKEN_BUFFER = []


def litellm_usage_callback(data):
    """
    LiteLLM passes:
    {
        "response": {
            "usage": {
                "prompt_tokens": int,
                "completion_tokens": int,
                "total_tokens": int
            }
        }
    }
    """
    try:
        if (
            isinstance(data, dict)
            and "response" in data
            and isinstance(data["response"], dict)
            and "usage" in data["response"]
        ):
            usage = data["response"]["usage"]

            GLOBAL_LLM_TOKEN_BUFFER.append(
                {
                    "input_tokens": usage.get("prompt_tokens", 0),
                    "output_tokens": usage.get("completion_tokens", 0),
                    "total_tokens": usage.get("total_tokens", 0),
                }
            )
    except Exception as e:
        print(f"[TOKEN CALLBACK ERROR] {e}")


# REGISTER THE CALLBACK
litellm.success_callback = [litellm_usage_callback]


# ============================================================
# ADK GLOBALS
# ============================================================

session_service = InMemorySessionService()
artifact_service = InMemoryArtifactService()

runner = Runner(
    app_name="RAGLoanAgent",
    agent=root_agent,
    session_service=session_service,
    artifact_service=artifact_service,
)

_DEFAULT_USER_ID = "user_ID123"
_CURRENT_SESSION_ID = "session_ABC123"


# ============================================================
# SESSION HELPERS
# ============================================================

def _new_session_id():
    return f"session_{uuid4().hex}"


async def _delete_session_if_exists(user_id, session_id):
    try:
        session = await session_service.get_session(
            app_name=runner.app_name, user_id=user_id, session_id=session_id
        )
        if session:
            await session_service.delete_session(
                app_name=runner.app_name, user_id=user_id, session_id=session_id
            )
    except Exception as e:
        print(f"Session delete warning: {e}")


def _reset_runtime_and_rotate_session():
    global session_service, artifact_service, runner, _CURRENT_SESSION_ID

    _CURRENT_SESSION_ID = _new_session_id()
    session_service = InMemorySessionService()
    artifact_service = InMemoryArtifactService()

    runner = Runner(
        app_name="RAGLoanAgent",
        agent=root_agent,
        session_service=session_service,
        artifact_service=artifact_service,
    )


# ============================================================
# MAIN EVENT LOOP
# ============================================================

async def main(VarQ: str):
    user_id = _DEFAULT_USER_ID
    session_id = _CURRENT_SESSION_ID

    print(f"Ensuring session '{session_id}' for user '{user_id}'...")

    # Create session if needed
    session = await session_service.get_session(
        app_name=runner.app_name, user_id=user_id, session_id=session_id
    )

    if not session:
        session = await session_service.create_session(
            app_name=runner.app_name,
            user_id=user_id,
            session_id=session_id,
            state={},
        )
        print("[OBS] Session created.")

    # Store query in session
    actions_with_update = EventActions(state_delta={"VarQ": VarQ})
    system_event = Event(
        invocation_id=f"set_varq_{int(time.time() * 1000)}",
        author="system",
        actions=actions_with_update,
        timestamp=time.time(),
    )
    await session_service.append_event(session, system_event)

    print("[OBS] Session state updated with VarQ.")
    print(f"\n>>> User Query: {VarQ}\n")

    content_to_send = types.Content(role="user", parts=[types.Part(text=VarQ)])

    final_response_text = ""
    event_counter = 0

    # timing metrics
    start_time = time.time()
    last_event_time = start_time

    # token accumulators
    total_input_tokens = 0
    total_output_tokens = 0

    # -----------------------------
    # ADK EVENT LOOP
    # -----------------------------
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session_id,
        new_message=content_to_send,
    ):
        event_counter += 1
        now = time.time()

        print(f"\n========== ADK EVENT #{event_counter} ==========")
        print(f"ID                : {event.id}")
        print(f"Author            : {event.author}")
        print(f"Timestamp         : {event.timestamp}")
        print(f"∆ Time from last  : {now - last_event_time:.3f}s")
        print(f"⏱ Total elapsed   : {now - start_time:.3f}s")
        print(f"Actions           : {event.actions}")

        last_event_time = now

        # ------------------------------------------------------
        # TOKEN USAGE (NEW WORKING VERSION)
        # ------------------------------------------------------
        if GLOBAL_LLM_TOKEN_BUFFER:
            usage = GLOBAL_LLM_TOKEN_BUFFER.pop(0)

            in_tok = usage["input_tokens"]
            out_tok = usage["output_tokens"]

            total_input_tokens += in_tok
            total_output_tokens += out_tok

            print(f"🟦 Input Tokens (event): {in_tok}")
            print(f"🟩 Output Tokens(event): {out_tok}")
            print(f"🔵 Total Input Tokens  : {total_input_tokens}")
            print(f"🟢 Total Output Tokens : {total_output_tokens}")

        # event content
        if event.content and hasattr(event.content, "parts"):
            text = "".join([p.text for p in event.content.parts if p.text])
            print(f"Content             : {text}")
            final_response_text = text

        print("=====================================\n")

        if event.is_final_response():
            break

    # After loop
    print("\n<<< FINAL AGENT RESPONSE >>>")
    print(final_response_text)

    print("\n===== TOKEN SUMMARY =====")
    print(f"Total Input Tokens  : {total_input_tokens}")
    print(f"Total Output Tokens : {total_output_tokens}")
    print(f"Total Tokens Used   : {total_input_tokens + total_output_tokens}")

    return final_response_text


# ============================================================
# WRAPPER
# ============================================================

def run_async(Input1: str):
    normalized = Input1.strip().lower()

    if normalized == "exit":
        asyncio.run(_delete_session_if_exists(_DEFAULT_USER_ID, _CURRENT_SESSION_ID))
        _reset_runtime_and_rotate_session()
        return "Session ended and memory reset."

    return asyncio.run(main(Input1))


# ============================================================
# CLI TEST
# ============================================================

if __name__ == "__main__":
    print(run_async("Explain the drifting mechanic in racing games."))
