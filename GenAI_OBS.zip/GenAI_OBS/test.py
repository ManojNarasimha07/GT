# test_tokens_minimal.py
import os
from dotenv import load_dotenv
import litellm

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY") or os.getenv("OPENAI_API_KEY")

GLOBAL_BUFFER = []

def cb(resp):
    if isinstance(resp, dict) and "usage" in resp:
        GLOBAL_BUFFER.append(resp["usage"])

litellm.success_callback = [cb]

def run_query(query: str):
    response = litellm.completion(
        model="gemini/gemini-2.0-flash",
        messages=[{"role":"user","content":query}]
    )
    usage = GLOBAL_BUFFER.pop(0) if GLOBAL_BUFFER else {}
    print("Usage:", usage)
    print("Output:", response)

if __name__ == "__main__":
    run_query("Explain drift mechanics in racing games.")
