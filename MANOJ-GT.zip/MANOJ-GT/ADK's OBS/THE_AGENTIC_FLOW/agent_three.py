import os
from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool      # <-- correct for ADK 1.19.0
from THE_AGENTIC_FLOW.litellm_with_usage import LiteLlmWithUsage

load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    raise ValueError("GOOGLE_API_KEY not found in .env")

model = LiteLlmWithUsage(
    model="gemini/gemini-2.0-flash",
    provider="google",
    api_key=api_key
)

# ----------------------------------------------------
# 1) Your custom financial math function (example)
# ----------------------------------------------------
def financial_math_tool(principal: float, rate: float, time: float) -> float:
    """
    Very simple interest calculation:
    A = P * (1 + r * t)
    """
    return principal * (1 + rate * time)


# ----------------------------------------------------
# 2) Math Agent instruction
# ----------------------------------------------------
AGENT_INSTRUCTION_MATH = """
You are a mathematics-only agent.
You answer questions involving:
- Algebra
- Arithmetic
- Geometry
- Trigonometry
- Statistics
- Calculus
- Financial math

If the question is financial math, you may call the financial_math_tool.
"""


# ----------------------------------------------------
# 3) Math Agent definition (WORKING)
# ----------------------------------------------------
root_agent_math = LlmAgent(
    name="MathAgent",
    description="Handles all math-related questions.",
    instruction=AGENT_INSTRUCTION_MATH,
    model=model,
    tools=[
        FunctionTool(financial_math_tool)   # <-- this is the correct way
    ]
)
