import os
from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from THE_AGENTIC_FLOW.litellm_with_usage import LiteLlmWithUsage
from uuid import uuid4

# ------------------------------------------------------
# Load environment variables (e.g., API keys)
# ------------------------------------------------------
load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")

if not api_key:
    raise ValueError("GOOGLE_API_KEY not found in .env")

# ------------------------------------------------------
# Configure the Gemini model for the Game Science agent
# ------------------------------------------------------
model = LiteLlmWithUsage(
    model="gemini/gemini-2.0-flash",
    provider="google",
    api_key=api_key
)




# ------------------------------------------------------
# Define the Game Science agent's instruction
# ------------------------------------------------------
AGENT_INSTRUCTION_GS = """
You are a game science-only Q&A assistant.
... (game-related topics here)
"""

# ------------------------------------------------------
# Initialize the Game Science agent
# ------------------------------------------------------
root_agent_gs = LlmAgent(
    name="GameScienceAgent",
    description="Game science-only agent. Responds to game science-related queries.",
    instruction=AGENT_INSTRUCTION_GS,
    model=model
)
