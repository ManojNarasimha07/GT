import asyncio
import time
import os
import random
from uuid import uuid4
import psutil

import litellm
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.artifacts import InMemoryArtifactService
from google.adk.events import Event, EventActions

from THE_AGENTIC_FLOW.agent import root_agent
from modular_smith import log_event_trace

# ============================================================
# ENV SETUP
# ============================================================

os.environ["ADK_SUPPRESS_GEMINI_LITELLM_WARNINGS"] = "true"

# ============================================================
# ADK GLOBALS
# ============================================================

session_service = InMemorySessionService()
artifact_service = InMemoryArtifactService()

runner = Runner(
    app_name="RAGLoanAgent",
    agent=root_agent,
    session_service=session_service,
    artifact_service=artifact_service,
)

_DEFAULT_USER_ID = "user_ID123"
_CURRENT_SESSION_ID = "session_ABC123"

# ============================================================
# SESSION HELPERS
# ============================================================

def _new_session_id():
    return f"session_{uuid4().hex}"

async def _delete_session_if_exists(user_id, session_id):
    try:
        session = await session_service.get_session(
            app_name=runner.app_name, user_id=user_id, session_id=session_id
        )
        if session:
            await session_service.delete_session(
                app_name=runner.app_name, user_id=user_id, session_id=session_id
            )
    except Exception as e:
        print(f"[OBS WARNING] Session delete failed: {e}")

def _reset_runtime_and_rotate_session():
    global session_service, artifact_service, runner, _CURRENT_SESSION_ID
    _CURRENT_SESSION_ID = _new_session_id()
    session_service = InMemorySessionService()
    artifact_service = InMemoryArtifactService()
    runner = Runner(
        app_name="RAGLoanAgent",
        agent=root_agent,
        session_service=session_service,
        artifact_service=artifact_service,
    )

# ============================================================
# MAIN EVENT LOOP
# ============================================================

async def main(VarQ: str):
    user_id = _DEFAULT_USER_ID
    session_id = _CURRENT_SESSION_ID

    print(f"Ensuring session '{session_id}' for user '{user_id}'...")

    session = await session_service.get_session(
        app_name=runner.app_name, user_id=user_id, session_id=session_id
    )
    if not session:
        session = await session_service.create_session(
            app_name=runner.app_name,
            user_id=user_id,
            session_id=session_id,
            state={},
        )
        print("[OBS] Session created.")

    actions_with_update = EventActions(state_delta={"VarQ": VarQ})
    system_event = Event(
        invocation_id=f"set_varq_{int(time.time() * 1000)}",
        author="system",
        actions=actions_with_update,
        timestamp=time.time(),
    )
    await session_service.append_event(session, system_event)
    print("[OBS] Session state updated with VarQ.")
    print(f"\n>>> User Query: {VarQ}\n")

    content_to_send = types.Content(role="user", parts=[types.Part(text=VarQ)])
    final_response_text = ""
    event_counter = 0

    total_input_tokens = 0
    total_output_tokens = 0

    try:
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=content_to_send,
        ):
            event_counter += 1

            # -----------------------------
            # Simulated latency (source)
            # -----------------------------
            simulated_latency = random.uniform(0.2, 1.2)
            time.sleep(simulated_latency)

            input_tokens = getattr(event.usage_metadata, "prompt_token_count", 0) if event.usage_metadata else 0
            output_tokens = getattr(event.usage_metadata, "candidates_token_count", 0) if event.usage_metadata else 0

            total_input_tokens += input_tokens
            total_output_tokens += output_tokens

            text_content = ""
            if event.content and hasattr(event.content, "parts"):
                text_content = "".join([p.text for p in event.content.parts if p.text])
                final_response_text = text_content

            # -----------------------------
            # LOG EVENT TO LANGSMITH
            # -----------------------------
            run_id = uuid4()

            usage_metadata = {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
            }

            log_event_trace(
                run_id=run_id,
                status="success",
                input_data=VarQ,
                output_data=text_content,
                usage_metadata=usage_metadata,
                latency=simulated_latency,
            )

            if event.is_final_response():
                break

    except Exception as e:
        print(f"[ERROR] Event loop failed: {e}")

    print("\n<<< FINAL AGENT RESPONSE >>>")
    print(final_response_text)

    print("\n===== TOKEN SUMMARY =====")
    print(f"Total Input Tokens  : {total_input_tokens}")
    print(f"Total Output Tokens : {total_output_tokens}")
    print(f"Total Tokens Used   : {total_input_tokens + total_output_tokens}")

    try:
        if hasattr(runner, "close"):
            await runner.close()
    except Exception as e:
        print(f"[OBS] Runner close warning: {e}")

    if hasattr(litellm, "DEFAULT_CLIENT") and litellm.DEFAULT_CLIENT:
        await litellm.DEFAULT_CLIENT.aclose()

    return final_response_text

# ============================================================
# WRAPPER
# ============================================================

def run_async(Input1: str):
    normalized = Input1.strip().lower()
    if normalized == "exit":
        asyncio.run(_delete_session_if_exists(_DEFAULT_USER_ID, _CURRENT_SESSION_ID))
        _reset_runtime_and_rotate_session()
        return "Session ended and memory reset."
    return asyncio.run(main(Input1))

# ============================================================
# CLI TEST
# ============================================================

if __name__ == "__main__":
    print(run_async("Explain the drifting mechanic in racing games."))
