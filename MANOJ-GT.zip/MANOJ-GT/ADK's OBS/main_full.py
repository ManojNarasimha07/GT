import asyncio
import time
import os
from uuid import uuid4
import psutil

import litellm
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.artifacts import InMemoryArtifactService
from google.adk.events import Event, EventActions

from THE_AGENTIC_FLOW.agent import root_agent

from modular_smith import log_event_trace as log_trace

# ============================================================
# ENV SETUP
# ============================================================

os.environ["ADK_SUPPRESS_GEMINI_LITELLM_WARNINGS"] = "true"

# ============================================================
# ADK GLOBALS
# ============================================================

session_service = InMemorySessionService()
artifact_service = InMemoryArtifactService()

runner = Runner(
    app_name="RAGLoanAgent",
    agent=root_agent,
    session_service=session_service,
    artifact_service=artifact_service,
)

_DEFAULT_USER_ID = "user_ID123"
_CURRENT_SESSION_ID = "session_ABC123"

# ============================================================
# SESSION HELPERS
# ============================================================

def _new_session_id():
    return f"session_{uuid4().hex}"

async def _delete_session_if_exists(user_id, session_id):
    try:
        session = await session_service.get_session(
            app_name=runner.app_name, user_id=user_id, session_id=session_id
        )
        if session:
            await session_service.delete_session(
                app_name=runner.app_name, user_id=user_id, session_id=session_id
            )
    except Exception as e:
        print(f"[OBS WARNING] Session delete failed: {e}")

def _reset_runtime_and_rotate_session():
    global session_service, artifact_service, runner, _CURRENT_SESSION_ID
    _CURRENT_SESSION_ID = _new_session_id()
    session_service = InMemorySessionService()
    artifact_service = InMemoryArtifactService()
    runner = Runner(
        app_name="RAGLoanAgent",
        agent=root_agent,
        session_service=session_service,
        artifact_service=artifact_service,
    )

# ============================================================
# MAIN EVENT LOOP
# ============================================================

async def main(VarQ: str):
    user_id = _DEFAULT_USER_ID
    session_id = _CURRENT_SESSION_ID

    print(f"Ensuring session '{session_id}' for user '{user_id}'...")

    # Create session if missing
    session = await session_service.get_session(
        app_name=runner.app_name, user_id=user_id, session_id=session_id
    )

    if not session:
        session = await session_service.create_session(
            app_name=runner.app_name,
            user_id=user_id,
            session_id=session_id,
            state={},
        )
        print("[OBS] Session created.")

    # Store query in session
    actions_with_update = EventActions(state_delta={"VarQ": VarQ})
    system_event = Event(
        invocation_id=f"set_varq_{int(time.time() * 1000)}",
        author="system",
        actions=actions_with_update,
        timestamp=time.time(),
    )
    await session_service.append_event(session, system_event)
    print("[OBS] Session state updated with VarQ.")
    print(f"\n>>> User Query: {VarQ}\n")

    content_to_send = types.Content(role="user", parts=[types.Part(text=VarQ)])
    final_response_text = ""
    event_counter = 0

    start_time = time.time()
    last_event_time = start_time

    total_input_tokens = 0
    total_output_tokens = 0

    # -----------------------------
    # ADK EVENT LOOP (per-event logging)
    # -----------------------------
    try:
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=content_to_send,
        ):
            event_counter += 1
            now = time.time()

            print(f"\n========== ADK EVENT #{event_counter} ==========")
            print(f"ID                : {event.id}")
            print(f"Author            : {event.author}")
            print(f"Timestamp         : {event.timestamp}")
            print(f"∆ Time from last  : {now - last_event_time:.3f}s")
            print(f"⏱ Total elapsed   : {now - start_time:.3f}s")
            last_event_time = now

            # -----------------------------
            # Actions & State Deltas
            # -----------------------------
            actions = event.actions
            print(f"Actions           : {actions}")

            if hasattr(actions, "state_delta") and actions.state_delta:
                print(f"Agent state delta : {actions.state_delta}")

            if hasattr(actions, "artifact_delta") and actions.artifact_delta:
                print(f"Artifact delta    : {actions.artifact_delta}")

            if hasattr(actions, "transfer_to_agent") and actions.transfer_to_agent:
                print(f"Message sent      : {actions.transfer_to_agent}")

            if hasattr(actions, "decision_info") and actions.decision_info:
                print(f"Decision info     : {actions.decision_info}")

            # -----------------------------
            # Token usage
            # -----------------------------
            in_tok = 0
            out_tok = 0
            if hasattr(event, "usage_metadata") and event.usage_metadata:
                usage = event.usage_metadata
                in_tok = getattr(usage, "prompt_token_count", 0)
                out_tok = getattr(usage, "candidates_token_count", 0)
                total_input_tokens += in_tok
                total_output_tokens += out_tok
                print(f"🟦 Input Tokens (event): {in_tok}")
                print(f"🟩 Output Tokens(event): {out_tok}")
                print(f"🔵 Total Input Tokens  : {total_input_tokens}")
                print(f"🟢 Total Output Tokens : {total_output_tokens}")
            else:
                print("No usage_metadata found in event.")

            # -----------------------------
            # Event content
            # -----------------------------
            event_text = ""
            if event.content and hasattr(event.content, "parts"):
                event_text = "".join([p.text for p in event.content.parts if p.text])
                print(f"Content             : {event_text}")
                final_response_text = event_text

            # -----------------------------
            # Performance metrics
            # -----------------------------
            proc = psutil.Process()
            print(f"Memory usage        : {proc.memory_info().rss / 1e6:.2f} MB")

            print("=====================================\n")

            # -----------------------------
            # PER-EVENT TRACE LOG
            # -----------------------------
            run_id = uuid4()
            event_latency = getattr(event, "timestamp", time.time()) - start_time
            usage_metadata = {
                "input_tokens": in_tok,
                "output_tokens": out_tok,
                "total_tokens": in_tok + out_tok,
            }

            status = "success"
            error_msg = None
            if event_text.strip() == "" or "error" in event_text.lower():
                status = "error"
                error_msg = "Model returned empty or error content."

            trace = log_trace(
                run_id=run_id,
                status=status,
                input_data=VarQ,
                output_data=event_text,
                error_msg=error_msg,
                usage_metadata=usage_metadata,
                model_name="gemini-2.0-flash",
                latency=event_latency,
            )

            print(f"===== TRACE LOG FOR EVENT #{event_counter} =====")
            print(trace)

            if event.is_final_response():
                break

    except Exception as e:
        print(f"[ERROR] Event loop failed: {e}")

    # -----------------------------
    # CLEANUP
    # -----------------------------
    try:
        if hasattr(runner, "close"):
            await runner.close()
    except Exception as e:
        print(f"[OBS] Runner close warning: {e}")

    if hasattr(litellm, "DEFAULT_CLIENT") and litellm.DEFAULT_CLIENT:
        await litellm.DEFAULT_CLIENT.aclose()

    return final_response_text

# ============================================================
# WRAPPER
# ============================================================

def run_async(Input1: str):
    normalized = Input1.strip().lower()
    if normalized == "exit":
        asyncio.run(_delete_session_if_exists(_DEFAULT_USER_ID, _CURRENT_SESSION_ID))
        _reset_runtime_and_rotate_session()
        return "Session ended and memory reset."
    return asyncio.run(main(Input1))

# ============================================================
# CLI TEST
# ============================================================

if __name__ == "__main__":
    print(run_async("If I invest $5000 at 6% for 8 years, what’s the final amount?"))


#===========================================================
# ABLE TO OBSERVE (CURRENT SYSTEM)
#===========================================================
# Event ID
# Author
# Token usage
# Content
# Actions
# Errors (when empty output)
# Latency
# Total memory consumption
# Correct LLM traces written to LangSmith
#===========================================================

#===========================================================
# FUTURE OBSERVABILITY ENHANCEMENTS TO ADD
#===========================================================
# Agent reasoning traces (intermediate chains of thought)
# Agent decision scores (why an agent selected a path)
# Routing confidence (probability of choosing agent X)
# Tool invocation logs (which tool, params, outputs)
# State snapshots (full agent state before and after event)
# Session-level metrics (LLM calls per session, avg latency)
# Resource usage per agent (RAM, CPU per event)
# Event anomalies (unexpected routing / missing fields)
# Retry logs (when LLM retries happen)
# Prompt versions (the exact prompt sent per event)
# Output schema validation (correctness, completeness)
# Safety checks fired (toxicity, risk flags)
#===========================================================


