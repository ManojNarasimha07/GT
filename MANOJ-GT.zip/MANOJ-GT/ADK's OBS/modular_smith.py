import datetime
from uuid import UUID
from langsmith import Client

client = Client()

def now_utc():
    return datetime.datetime.now(datetime.timezone.utc)

def log_event_trace(
    run_id,
    status,
    input_data,
    output_data=None,
    error_msg=None,
    error_details=None,
    usage_metadata=None,
    latency=None,
    model_name="gemini-2.0-flash"
):
    # Safety defaults
    if latency is None:
        latency = 0.0

    # Round latency so LangSmith accepts it (IMPORTANT)
    latency = round(latency, 3)

    if usage_metadata is None:
        usage_metadata = {}

    # Create proper timestamps so LangSmith UI shows latency
    start = now_utc()
    end = start + datetime.timedelta(seconds=latency)

    if status == "error" and not error_details:
        error_details = "The model produced unexpected output due to hallucination."

    response = client.create_run(
        id=run_id,
        name="simple_llm_run",
        run_type="llm",
        project_name="ADK_GT",
        inputs={"input": input_data},
        outputs={"output": output_data} if output_data else None,
        start_time=start,
        end_time=end,
        status=status,
        error=error_msg,
        extra={
            "latency": latency,  # TOP-LEVEL FIELD LangSmith UI reads
            "metadata": {
                "usage_metadata": usage_metadata,
                "ls_model_name": model_name,
                "latency": latency,  # inside metadata
                "error_details": error_details,
            }
        },
    )

    return {
        "id": str(run_id),
        "status": status,
        "error": error_msg,
        "usage_metadata": usage_metadata,
        "latency": latency,
        "metadata": {
            "latency": latency,
            "error_details": error_details,
            "ls_model_name": model_name,
        },
        "response": response,
    }
