import os
import time
import uuid
from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import BaseTool
from modular_smith import log_event_trace  # Import your logging function

# Math Tool
class MathTool(BaseTool):
    name: str = "Math Calculator"
    description: str = "Performs basic math operations (add, subtract, multiply, divide)."

    def _run(self, operation: str, a: float, b: float) -> str:
        if operation == "add":
            return f"{a} + {b} = {a + b}"
        elif operation == "subtract":
            return f"{a} - {b} = {a - b}"
        elif operation == "multiply":
            return f"{a} * {b} = {a * b}"
        elif operation == "divide":
            if b == 0:
                return "Cannot divide by zero."
            return f"{a} / {b} = {a / b}"
        else:
            return "Invalid operation."

# Set your API key
os.environ['GOOGLE_API_KEY'] = 'AIzaSyAvgp0-x-fbpyM9WHFOLPRFrybJE2HYgck'

llm = LLM(
    model="gemini/gemini-2.0-flash",
    api_key=os.getenv("GOOGLE_API_KEY"),
    temperature=0.7
)

# Router Agent
router = Agent(
    role="Question Router",
    goal="Analyze kids' questions and decide the correct subject agent (math, science, social)",
    backstory="You are an expert in understanding kids' questions and routing them to the right subject expert.",
    verbose=True,
    llm=llm
)

# Math Agent with Tool
math_agent = Agent(
    role="Math Expert",
    goal="Answer math questions for kids using the Math Calculator tool",
    backstory="You are a fun and friendly math expert who loves helping kids.",
    tools=[MathTool()],
    verbose=True,
    llm=llm
)

# Science Agent
science_agent = Agent(
    role="Science Expert",
    goal="Answer science questions for kids",
    backstory="You are a passionate science expert who makes learning fun for kids.",
    verbose=True,
    llm=llm
)

# Social Agent
social_agent = Agent(
    role="Social Studies Expert",
    goal="Answer social questions for kids",
    backstory="You are a knowledgeable social studies expert who loves teaching kids.",
    verbose=True,
    llm=llm
)

# Chat loop
def exe():
    print("💬 Assistant: HI")
    while True:
        user_input = input("\n🔤 You: ").strip()
        if user_input.lower() in {"quit", "exit"}:
            print("👋 Bye! Ending chat.")
            break

        # Router task: Decide subject
        route_task = Task(
            description=f"Analyze the question and decide if it should go to math, science, or social agent. Only reply with one word: math, science, or social. Question: {user_input}",
            expected_output="One word: math, science, or social",
            agent=router
        )
        route_crew = Crew(agents=[router], tasks=[route_task], process=Process.sequential, verbose=False, llm=llm)
        start_time = time.time()
        result = route_crew.kickoff()
        end_time = time.time()
        subject = result.raw.strip().lower()
        latency = end_time - start_time
        usage_metadata = {
            "input_tokens": result.token_usage.prompt_tokens,
            "output_tokens": result.token_usage.completion_tokens
        }

        # Log to LangSmith
        log_event_trace(
            run_id=uuid.uuid4(),
            status="success",
            input_data={"question": user_input},
            output_data={"subject": subject, "analysis": result.raw},
            usage_metadata=usage_metadata,
            latency=latency
        )

        # Dynamically create crew with only the selected agent and task
        if subject == "math":
            task = Task(
                description=f"Answer the math question using the Math Calculator tool. Question: {user_input}",
                expected_output="A simple, kid-friendly answer to the math question",
                agent=math_agent
            )
            subject_crew = Crew(agents=[math_agent], tasks=[task], process=Process.sequential, verbose=True, llm=llm)
        elif subject == "science":
            task = Task(
                description=f"Answer the science question. Question: {user_input}",
                expected_output="A simple, kid-friendly answer to the science question",
                agent=science_agent
            )
            subject_crew = Crew(agents=[science_agent], tasks=[task], process=Process.sequential, verbose=True, llm=llm)
        elif subject == "social":
            task = Task(
                description=f"Answer the social question. Question: {user_input}",
                expected_output="A simple, kid-friendly answer to the social question",
                agent=social_agent
            )
            subject_crew = Crew(agents=[social_agent], tasks=[task], process=Process.sequential, verbose=True, llm=llm)
        else:
            print("Router: I don't know how to help with that.")
            continue

        # Run only the relevant subject crew
        start_time = time.time()
        result = subject_crew.kickoff()
        end_time = time.time()
        latency = end_time - start_time
        usage_metadata = {
            "input_tokens": result.token_usage.prompt_tokens,
            "output_tokens": result.token_usage.completion_tokens
        }

        # Log to LangSmith
        log_event_trace(
            run_id=uuid.uuid4(),
            status="success",
            input_data={"question": user_input},
            output_data={"answer": result.raw},
            usage_metadata=usage_metadata,
            latency=latency
        )
        print(f"✅ Answer: {result.raw}")

if __name__ == "__main__":
    exe()
