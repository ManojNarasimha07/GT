import os
import time
import uuid
from typing import TypedDict, Literal

from langchain.chat_models import init_chat_model
from langchain.tools import tool
from langchain.agents import create_agent
from langgraph.graph import StateGraph, END
from langchain_core.prompts import ChatPromptTemplate
from pydantic.v1 import BaseModel, Field
from langchain_core.output_parsers import JsonOutputParser

# Import logging from modular_smith
from modular_smith import log_event_trace


os.environ["GOOGLE_API_KEY"] = "AIzaSyAvgp0-x-fbpyM9WHFOLPRFrybJE2HYgck"
model = init_chat_model("google_genai:gemini-2.5-flash-lite")


@tool
def academic_score_tool(question: str) -> str:
    """Score the academic validity and curiosity of a question."""
    return "This is a placeholder scoring tool. Treat all questions as validity=8, curiosity=8 for now."


@tool
def social_search(query: str) -> str:
    """Answer questions related to social sciences or humanities."""
    return f"[SOCIAL_TOOL] Academic-style explanation for: {query}"


@tool
def maths_solver(problem: str) -> str:
    """Solve a mathematics question at an academic level."""
    return f"[MATHS_TOOL] Worked-out style solution for: {problem}"


@tool
def science_info(query: str) -> str:
    """Explain scientific concepts or questions."""
    return f"[SCIENCE_TOOL] Scientific explanation for: {query}"


root_agent = create_agent(model, tools=[academic_score_tool])
social_agent = create_agent(model, tools=[social_search])
maths_agent = create_agent(model, tools=[maths_solver])
science_agent = create_agent(model, tools=[science_info])


class GraphState(TypedDict):
    question: str
    subject: Literal["social", "maths", "science", "unknown"]
    root_analysis: str
    answer: str


class RoutingOutput(BaseModel):
    root_analysis: str = Field(description="Explanation of routing decision")
    subject: str = Field(description="One of: social, maths, science")


parser = JsonOutputParser(pydantic_object=RoutingOutput)


def extract_token_usage(messages) -> tuple[int, int]:
    input_tokens = 0
    output_tokens = 0
    for msg in messages:
        usage = getattr(msg, "usage_metadata", None)
        if usage:
            input_tokens += usage.get("input_tokens", 0)
            output_tokens += usage.get("output_tokens", 0)
    return input_tokens, output_tokens


def root_node(state: GraphState) -> GraphState:
    question = state["question"]
    start_time = time.time()
    event_id = uuid.uuid4()
    print(f"========== ADK EVENT #{event_id.hex[:8]} ==========")
    print(f"Author            : RootAgent")
    print(f"Timestamp         : {start_time}")
    print(f"Actions           : Scored question and routed to subject expert")
    print(f"Content           : Evaluated question: {question}")
    print("=====================================")

    prompt = (
        "You are an academic query router.\n"
        f"User question: {question}\n\n"
        "Tasks:\n"
        "1) Use the academic_score_tool to estimate academic validity and curiosity.\n"
        "2) Decide best subject: one of [social, maths, science].\n"
        "3) Reply in this JSON format:\n"
        "{\n"
        "  \"root_analysis\": \"<short reasoning>\",\n"
        "  \"subject\": \"<social|maths|science>\"\n"
        "}\n"
        f"{parser.get_format_instructions()}\n"
    )
    result = root_agent.invoke(
        {
            "messages": [{"role": "user", "content": prompt}]
        },
        context={"user_role": "router"},
    )
    try:
        parsed = parser.parse(result["messages"][-1].content)
        subject = parsed["subject"].lower()
        root_analysis = parsed["root_analysis"]
    except Exception:
        subject = "unknown"
        root_analysis = result["messages"][-1].content if result["messages"] else ""

    input_tokens, output_tokens = extract_token_usage(result["messages"])
    end_time = time.time()
    latency = end_time - start_time
    usage_metadata = {"input_tokens": input_tokens, "output_tokens": output_tokens}

    # Log to LangSmith with consistent project_name
    log_event_trace(
        run_id=event_id,
        status="success",
        input_data=prompt,
        output_data=result["messages"][-1].content,
        usage_metadata=usage_metadata,
        latency=latency,
        model_name="gemini-2.5-flash-lite"
    )

    print(f"[DEBUG] root_node output: subject={subject}, root_analysis={root_analysis}")
    print(f"🟦 Input Tokens (event): {input_tokens}")
    print(f"🟩 Output Tokens (event): {output_tokens}")
    print(f"⏱ Latency: {latency:.3f}s")
    print("=====================================")

    return {
        "question": question,
        "subject": subject,
        "root_analysis": root_analysis,
        "answer": state.get("answer", ""),
    }


def social_node(state: GraphState) -> GraphState:
    q = state["question"]
    start_time = time.time()
    event_id = uuid.uuid4()
    print(f"========== ADK EVENT #{event_id.hex[:8]} ==========")
    print(f"Author            : SocialAgent")
    print(f"Timestamp         : {start_time}")
    print(f"Actions           : Provided academic explanation for question")
    print(f"Content           : Explained social science concept: {q}")
    print("=====================================")

    result = social_agent.invoke(
        {"messages": [{"role": "user", "content": q}]},
        context={"user_role": "social_expert"},
    )
    final_answer = result["messages"][-1].content if result["messages"] else ""
    input_tokens, output_tokens = extract_token_usage(result["messages"])
    end_time = time.time()
    latency = end_time - start_time
    usage_metadata = {"input_tokens": input_tokens, "output_tokens": output_tokens}

    # Log to LangSmith with consistent project_name
    log_event_trace(
        run_id=event_id,
        status="success",
        input_data=q,
        output_data=final_answer,
        usage_metadata=usage_metadata,
        latency=latency,
        model_name="gemini-2.5-flash-lite"
    )

    print(f"[DEBUG] Social agent response: {final_answer}")
    print(f"🟦 Input Tokens (event): {input_tokens}")
    print(f"🟩 Output Tokens (event): {output_tokens}")
    print(f"⏱ Latency: {latency:.3f}s")
    print("=====================================")
    return {**state, "answer": final_answer}


def maths_node(state: GraphState) -> GraphState:
    q = state["question"]
    start_time = time.time()
    event_id = uuid.uuid4()
    print(f"========== ADK EVENT #{event_id.hex[:8]} ==========")
    print(f"Author            : MathsAgent")
    print(f"Timestamp         : {start_time}")
    print(f"Actions           : Solved mathematical problem or defined concept")
    print(f"Content           : Defined prime number for question: {q}")
    print("=====================================")

    result = maths_agent.invoke(
        {"messages": [{"role": "user", "content": q}]},
        context={"user_role": "maths_expert"},
    )
    final_answer = result["messages"][-1].content if result["messages"] else ""
    input_tokens, output_tokens = extract_token_usage(result["messages"])
    end_time = time.time()
    latency = end_time - start_time
    usage_metadata = {"input_tokens": input_tokens, "output_tokens": output_tokens}

    # Log to LangSmith with consistent project_name
    log_event_trace(
        run_id=event_id,
        status="success",
        input_data=q,
        output_data=final_answer,
        usage_metadata=usage_metadata,
        latency=latency,
        model_name="gemini-2.5-flash-lite"
    )

    print(f"[DEBUG] Maths agent response: {final_answer}")
    print(f"🟦 Input Tokens (event): {input_tokens}")
    print(f"🟩 Output Tokens (event): {output_tokens}")
    print(f"⏱ Latency: {latency:.3f}s")
    print("=====================================")
    return {**state, "answer": final_answer}


def science_node(state: GraphState) -> GraphState:
    q = state["question"]
    start_time = time.time()
    event_id = uuid.uuid4()
    print(f"========== ADK EVENT #{event_id.hex[:8]} ==========")
    print(f"Author            : ScienceAgent")
    print(f"Timestamp         : {start_time}")
    print(f"Actions           : Explained scientific concept")
    print(f"Content           : Explained scientific concept: {q}")
    print("=====================================")

    result = science_agent.invoke(
        {"messages": [{"role": "user", "content": q}]},
        context={"user_role": "science_expert"},
    )
    final_answer = result["messages"][-1].content if result["messages"] else ""
    input_tokens, output_tokens = extract_token_usage(result["messages"])
    end_time = time.time()
    latency = end_time - start_time
    usage_metadata = {"input_tokens": input_tokens, "output_tokens": output_tokens}

    # Log to LangSmith with consistent project_name
    log_event_trace(
        run_id=event_id,
        status="success",
        input_data=q,
        output_data=final_answer,
        usage_metadata=usage_metadata,
        latency=latency,
        model_name="gemini-2.5-flash-lite"
    )

    print(f"[DEBUG] Science agent response: {final_answer}")
    print(f"🟦 Input Tokens (event): {input_tokens}")
    print(f"🟩 Output Tokens (event): {output_tokens}")
    print(f"⏱ Latency: {latency:.3f}s")
    print("=====================================")
    return {**state, "answer": final_answer}


def route_subject(state: GraphState) -> str:
    subject = state["subject"]
    print(f"[DEBUG] Routing to subject: {subject}")
    if subject == "social":
        return "social_node"
    if subject == "maths":
        return "maths_node"
    if subject == "science":
        return "science_node"
    return END


def build_graph():
    workflow = StateGraph(GraphState)

    workflow.add_node("root", root_node)
    workflow.add_node("social_node", social_node)
    workflow.add_node("maths_node", maths_node)
    workflow.add_node("science_node", science_node)

    workflow.set_entry_point("root")

    workflow.add_conditional_edges(
        "root",
        route_subject,
        {
            "social_node": "social_node",
            "maths_node": "maths_node",
            "science_node": "science_node",
            END: END,
        },
    )

    workflow.add_edge("social_node", END)
    workflow.add_edge("maths_node", END)
    workflow.add_edge("science_node", END)

    app = workflow.compile()
    return app


if __name__ == "__main__":
    app = build_graph()
    user_question = input("Enter your academic question: ")
    start_time = time.time()
    final_state = app.invoke(
        {
            "question": user_question,
            "subject": "unknown",
            "root_analysis": "",
            "answer": "",
        }
    )
    end_time = time.time()
    print(f"\n⏱ Total elapsed   : {end_time - start_time:.3f}s")
    print("\n[ROOT ANALYSIS]\n", final_state["root_analysis"])
    print("\n[FINAL ANSWER]\n", final_state["answer"])
