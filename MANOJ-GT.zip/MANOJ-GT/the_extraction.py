import os

def dump_python_files(root_folder):
    output_file = os.path.join(root_folder, "python_files_dump.txt")
    
    with open(output_file, "w", encoding="utf-8") as out_f:
        for dirpath, _, filenames in os.walk(root_folder):
            for filename in filenames:
                if filename.endswith(".py"):
                    file_path = os.path.join(dirpath, filename)
                    out_f.write(f"==== FILE: {file_path} ====\n")
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            content = f.read()
                        out_f.write(content + "\n\n")
                    except Exception as e:
                        out_f.write(f"[ERROR READING FILE: {e}]\n\n")
    
    print(f"All Python files have been dumped into: {output_file}")


# ==========================
# SAMPLE CALL
# ==========================
if __name__ == "__main__":
    root_path = r"C:\Users\ManojNarasimha\MANOJ-GT\ADK's OBS"
    dump_python_files(root_path)

# ==========================