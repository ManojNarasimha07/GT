from google.adk.agents import LlmAgent
from google.adk.tools.agent_tool import AgentTool
from . import  prompt
from .subagents.agent1 import Agent1
from .subagents.agent2 import Agent2
from .subagents.agent3 import Agent3
from .subagents.agent4 import Agent4



MODEL = "gemini-2.0-flash"
AssistantAgent = LlmAgent(
    name="AssistantAgent",
    model=MODEL,  
    description="Root agent that splits the query, if multiple questions are there and calls the respective agents by providing the question as input to get the answers.",
    instruction=prompt.AGENT_UNDERSTANDING,
    tools=[
        AgentTool(agent=Agent1),
        AgentTool(agent=Agent2),
        AgentTool(agent=Agent3),
        AgentTool(agent=Agent4),
    ],
)
root_agent = AssistantAgent

