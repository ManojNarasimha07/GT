from google.adk.agents import LlmAgent
from . import prompt
import faiss
import pickle
import os
from google.adk.tools import FunctionTool
from sentence_transformers import SentenceTransformer

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
GT100_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))
def retriving(query:str)->list:
    INDEX_FILE = os.path.join(GT100_DIR, "chunks", "faiss_index.bin")
    METADATA_FILE = os.path.join(GT100_DIR, "chunks", "faiss_metadata.pkl")
    EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
    TOP_K = 3
    print(f"Loading index from '{INDEX_FILE}'...")
    index = faiss.read_index(INDEX_FILE)

    print(f"Loading metadata from '{METADATA_FILE}'...")
    with open(METADATA_FILE, "rb") as f:
        meta_data = pickle.load(f)
    ids = meta_data["ids"]
    metadatas = meta_data["metadatas"]
    documents = meta_data["documents"]

    print(f"Loading embedding model '{EMBEDDING_MODEL_NAME}'...")
    embed_model = SentenceTransformer(EMBEDDING_MODEL_NAME)

    query_embedding = embed_model.encode([query], convert_to_numpy=True)
    faiss.normalize_L2(query_embedding)

    distances, indices = index.search(query_embedding, TOP_K)

    context_chunks = []

    for rank, (dist, idx) in enumerate(zip(distances[0], indices[0]), start=1):
        idx = int(idx)
        dist = float(dist)
        chunk_text = documents[idx]
        meta = metadatas[idx]

        context_chunks.append({
            "rank": rank,
            "distance_score": dist,
            "chunk_text": chunk_text,
            "metadata": meta
        })
    return context_chunks
# 🧠 LLM Agent Definition
MODEL = "gemini-2.0-flash"
Agent3 = LlmAgent(
    name="Agent3",
    model=MODEL,
    description="Generates code based on RAG chunks.",
    instruction=prompt.CODE_DEBUGGING_INSTRUCTION,
    tools = [FunctionTool(retriving)],
    
)
