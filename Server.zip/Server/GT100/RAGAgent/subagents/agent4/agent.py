from google.adk.agents import LlmAgent
from . import prompt
from GT100.RAGAgent.subagents.agent1 import Agent1
from GT100.RAGAgent.subagents.agent2 import Agent2
from GT100.RAGAgent.subagents.agent3 import Agent3
from google.adk.tools.agent_tool import AgentTool

from google.adk.models.lite_llm import LiteLlm


import litellm
litellm._turn_on_debug()



GROQ_API_KEY = "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"

# # --- Step 3: Define the Agent with a GroqCloud Model ---
groq_model = LiteLlm(
    model="groq/llama-3.1-8b-instant",
    api_key=GROQ_API_KEY
)


Agent4 = LlmAgent(
    name="Agent4",
    model=groq_model,
    description="This Agent will take user query and subagent response as input and Anlayze the Confidence score, calls subagent again if confidence score is less.",
    instruction=prompt.EVALUATION_INSTRUCTION1,
        tools=[
        AgentTool(agent=Agent1),
        AgentTool(agent=Agent2),
        AgentTool(agent=Agent3),
    ],
)
