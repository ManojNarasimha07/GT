import asyncio
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.artifacts import InMemoryArtifactService



# --- Step 1: Import Your Root Agent ---
from GT100.RAGAgent.Agent import AssistantAgent as root_agent

# --- Step 2: Define the Asynchronous Main Function ---
# It now correctly accepts VarQ as an argument.
async def main(VarQ: str):
    """
    Sets up the ADK Runner and orchestrates a conversation with the agent.
    """
    print("Initializing ADK services...")
    session_service = InMemorySessionService()
    artifact_service = InMemoryArtifactService()

    # --- Step 3: Instantiate the Runner ---
    print("Creating the agent runner...")
    runner = Runner(
        app_name="RAGLoanAgent",
        agent=root_agent,
        session_service=session_service,
        artifact_service=artifact_service,
    )

    # --- Step 4: Set up Session and User Context ---
    user_id = "user_123"
    session_id = "session_abc"

    print(f"Creating session '{session_id}' for user '{user_id}'...")

    # --- THIS IS THE KEY CHANGE ---
    # When creating the session, we now pass an initial state dictionary.
    # The key 'VarQ' matches your prompt's placeholder {{VarQ}}.
    # The value is the VarQ variable that was passed into this function.
    await session_service.create_session(
        app_name=runner.app_name,
        user_id=user_id,
        session_id=session_id,
        state={'VarQ': VarQ}  # <-- THIS LINE IS THE FIX
    )
    print("Session created with initial state.")

    print(f"\nStarting conversation...")
    print(f">>> User Query (from variable): {VarQ}")

    # --- Step 5: Send an empty message to trigger the agent ---
    # We no longer need to send the user_query here because the full query
    # is already injected into the agent's instructions via the session state.
    # We just need to kick off the run.
    content_to_send = types.Content(role='user', parts=[types.Part(text="")]) # Sending an empty part is fine.

    # --- Step 6: Run the Agent and Process the Response ---
    final_response_text = "Agent did not produce a final response."
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session_id,
        new_message=content_to_send, # This just starts the process
    ):
        if event.is_final_response():
            if event.content and event.content.parts:
                final_response_text = event.content.parts[0].text
            break

    print(f"<<< Agent: {final_response_text}")
    return final_response_text

# --- Step 7: Run the main async function ---
if __name__ == "__main__":
    # Define the query here and pass it directly to the main function.
    query_to_process = "which function is responsible for adding items to cart"
    asyncio.run(main(query_to_process))

def run_async(Input1):
    return asyncio.run(main(Input1))
