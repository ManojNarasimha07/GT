from dotenv import load_dotenv
load_dotenv(dotenv_path='GT100/RAGAgent/.env')


from flask import Flask, request, jsonify
import retrieving
import GT100.main as AgentI

# Create a Flask app instance
app = Flask(__name__)

# Define an API endpoint at the URL '/process'
@app.route('/process', methods=['POST'])
def process_text():
    """
    Receives JSON with a 'text' field, counts its length,
    and returns the result.
    """
    # Get the JSON data from the incoming request
    data = request.get_json()

    # Basic error handling: check if 'text' key exists
    if not data or 'text' not in data:
        return jsonify({"error": "Missing 'text' field in request"}), 400

    # Get the text from the JSON payload
    text_to_process = data['text']
    
    # --- This is where your core logic goes ---
    # For now, we'll just count the length.
    #Texttochat = retrieving.main(text_to_process)

    Texttochat = AgentI.run_async(text_to_process)


    #Texttochat= Textfromchat[::-1]+str(len(Textfromchat))
    # ---

    # Return the result as a JSON response
    return jsonify({
        "original_text": text_to_process,
        "length": Texttochat,
        "message": "Processed successfully"
    })

# This allows you to run the server directly for testing
if __name__ == '__main__':
    # Runs the app on http://127.0.0.1:5000
    app.run(debug=True)
