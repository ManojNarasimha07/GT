import faiss
import pickle
from sentence_transformers import SentenceTransformer
import google.generativeai as genai
import os
import json

INDEX_FILE = os.path.join("chunks", "faiss_index.bin")
METADATA_FILE = os.path.join("chunks", "faiss_metadata.pkl")
# INDEX_FILE= "faiss_index.bin"
# METADATA_FILE = "faiss_metadata.pkl"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
TOP_K = 3
API_KEY = "AIzaSyC2wnAFSZodwQeDzveG_7wiwBTeQSXxA-8"
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemini-1.5-flash")

def main(input_chat):
    print(f"Loading index from '{INDEX_FILE}'...")
    index = faiss.read_index(INDEX_FILE)

    print(f"Loading metadata from '{METADATA_FILE}'...")
    with open(METADATA_FILE, "rb") as f:
        meta_data = pickle.load(f)
    ids = meta_data["ids"]
    metadatas = meta_data["metadatas"]
    documents = meta_data["documents"]

    print(f"Loading embedding model '{EMBEDDING_MODEL_NAME}'...")
    embed_model = SentenceTransformer(EMBEDDING_MODEL_NAME)

    query = input_chat
    query_embedding = embed_model.encode([query], convert_to_numpy=True)
    faiss.normalize_L2(query_embedding)

    distances, indices = index.search(query_embedding, TOP_K)

    context_chunks = []

    for rank, (dist, idx) in enumerate(zip(distances[0], indices[0]), start=1):
        idx = int(idx)
        dist = float(dist)
        chunk_text = documents[idx]
        meta = metadatas[idx]

        context_chunks.append({
            "rank": rank,
            "distance_score": dist,
            "chunk_text": chunk_text,
            "metadata": meta
        })

    prompt = (
        "You are an AI assistant. Use the following code chunks as context to answer the user's query.\n\n"
        f"Context chunks:\n{json.dumps(context_chunks, indent=2)}\n\n"
        f"User query:\n{query}\n\n"
        "Answer concisely based on the context above:"
        "if answer is a code snippet, return it in a code block with triple backticks with heading as \"CODE\".\n"
    )

    print("Sending combined query and context to Gemini model...")

    response = model.generate_content(prompt)

    if not response.candidates:
        raise RuntimeError("No response from Gemini LLM.")

    if hasattr(response.candidates, "message"):
        answer = response.candidates[0].message.content.strip()
    else:
        answer = response.candidates[0].content.parts[0].text.strip()


    print("\n=== Gemini AI Answer ===")
    print(answer)
    print("========================\n")
    return answer

# if __name__ == "__main__":
#     main("public void setBid(int bid) {\r\n    this.bid = bid;\r\n}, what is the purpose of this function?"
# )
