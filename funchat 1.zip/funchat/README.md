# Comet Extension

This is a simple VS Code extension that adds a chat participant named `@comet`.

## Features

When you use `@comet` in the chat view, it takes your text, runs a Python script to count the number of characters, and returns the result.

Example: `@comet Hello World` will return that the text length is 11.
