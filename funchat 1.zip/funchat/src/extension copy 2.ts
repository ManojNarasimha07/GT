import * as vscode from 'vscode';
import { exec } from 'child_process';
import * as path from 'path';

export function activate(context: vscode.ExtensionContext) {

    // Define the chat handler that will process the chat requests
    const handler: vscode.ChatRequestHandler = async (
        request: vscode.ChatRequest,
        chatContext: vscode.ChatContext,
        stream: vscode.ChatResponseStream,
        token: vscode.CancellationToken
    ) => {

        // Get the text the user wrote after "@funchat"
        const prompt = request.prompt;

        // Get the full, absolute path to the python script
        const scriptPath = path.join(context.extensionPath, 'count_length.py');
        
        // Construct the command to execute, ensuring paths and inputs with spaces are quoted
        const command = `python "${scriptPath}" "${prompt.replace(/"/g, '\\"')}"`;

        // Create a promise to handle the asynchronous execution of the Python script
        const execPromise = new Promise<string>((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    console.error(`Python script execution error: ${error}`);
                    reject(stderr); // Reject with the standard error output
                    return;
                }
                resolve(stdout.trim()); // Resolve with the standard output
            });
        });

        try {
            // Give the user immediate feedback that something is happening
            stream.progress('Running Custom extention to answer...');

            // Wait for the python script to finish
            const pyout = await execPromise;
            
            // Stream the final result back to the chat window using markdown
            stream.markdown(`The Output from "PYTHON FILE": **${pyout}** `);

        } catch (err) {
            // If there's an error from the script, report it clearly in the chat
            stream.markdown(`Sorry, I ran into a Python error: \n\n\`\`\`\n${err}\n\`\`\``);
        }

        // The handler must return an empty object or a result object
        return {}; 
    };

    // Create the chat participant and register it with VS Code
    const participant = vscode.chat.createChatParticipant('comet.participant', handler);

    // Set an icon for the participant (this is done in code)
    participant.iconPath = new vscode.ThemeIcon('symbol-string');

    // Add the participant to the extension's subscriptions to be properly disposed of
    context.subscriptions.push(participant);
}

// This method is called when your extension is deactivated
export function deactivate() {}
