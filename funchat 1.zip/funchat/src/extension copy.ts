import * as vscode from 'vscode';
import { exec } from 'child_process';
import * as path from 'path'; // <-- Add this line at the top

export function activate(context: vscode.ExtensionContext) {

    console.log('Congratulations, your extension "funchat" is now active!');

    const disposable = vscode.commands.registerCommand('funchat.helloWorld', () => {
        vscode.window.showInputBox({ placeHolder: 'Enter text to count length' }).then((input) => {
            if (!input) {
                vscode.window.showInformationMessage('No text entered');
                return;
            }

            // Get the full path to the python script
            const scriptPath = path.join(context.extensionPath, 'count_length.py');

            // IMPORTANT: Wrap paths with spaces in quotes
            const command = `python "${scriptPath}" "${input.replace(/"/g, '\\"')}"`;

            exec(command, (error, stdout, stderr) => {
                if (error) {
                    vscode.window.showErrorMessage(`Error running Python: ${stderr}`);
                    return;
                }
                vscode.window.showInformationMessage(`Text length: ${stdout.trim()}`);
            });
        });
    });

    context.subscriptions.push(disposable);
}

export function deactivate() {}
