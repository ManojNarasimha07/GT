import * as vscode from 'vscode';
import fetch from 'node-fetch'; // Import the fetch library

export function activate(context: vscode.ExtensionContext) {

    // Define the chat handler that will process the chat requests
    const handler: vscode.ChatRequestHandler = async (
        request: vscode.ChatRequest,
        chatContext: vscode.ChatContext,
        stream: vscode.ChatResponseStream,
        token: vscode.CancellationToken
    ) => {
        // The URL of your Python API endpoint
        const apiUrl = 'http://127.0.0.1:5000/process';

        try {
            // Give the user immediate feedback
            stream.progress('Sending text to the Comet service...');

            // Make a POST request to the Python API
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                // Send the user's prompt in the request body
                body: JSON.stringify({ text: request.prompt }),
            });

            // Check if the network request was successful
            if (!response.ok) {
                // Throw an error with the status text if something went wrong
                throw new Error(`API Error: ${response.statusText}`);
            }

            // Parse the JSON response from the server
            const jsonResponse = await response.json() as { length: string };
            
            // Stream the final result back to the chat window
            stream.markdown(`The Test Recived to JS : **${jsonResponse.length}** <end>.`);

        } catch (err: any) {
            // Handle network errors or other issues
            console.error(err);
            stream.markdown(`Sorry, I couldn't connect to the Comet service. Please make sure the backend is running.\n\n\`\`\`\n${err.message}\n\`\`\``);
        }

        return {}; 
    };

    // Create and register the chat participant
    const participant = vscode.chat.createChatParticipant('comet.participant', handler);
    participant.iconPath = new vscode.ThemeIcon('symbol-string');
    context.subscriptions.push(participant);
}

export function deactivate() {}
